class cli:
    def __init__(self, cmdline):
        ''' A command line interface in python created from the command line interface in linux.
        '''
        
        self.cmd = cmdline
        